# SMOKE Onboarding

Day one checklist.

![The logo](img/logo.png)

![A web picture](https://example.com/web.png)
