# SMOKE Write the spec

The row's own page.
